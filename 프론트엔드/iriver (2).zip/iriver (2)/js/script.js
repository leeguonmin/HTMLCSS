// alert("안녕하세유");


// document.querySelector(".visual .slider").slick();

// $(".visual .slider").slick();


$(document).ready(function () {


    $(".visual .slider").slick();


})